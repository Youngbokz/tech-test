<?php

namespace Container1JU6lhK;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/lib/Doctrine/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolderfce3e = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializere62fc = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties20d82 = [
        
    ];

    public function getConnection()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getConnection', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getMetadataFactory', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getExpressionBuilder', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'beginTransaction', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->beginTransaction();
    }

    public function getCache()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getCache', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getCache();
    }

    public function transactional($func)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'transactional', array('func' => $func), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'wrapInTransaction', array('func' => $func), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'commit', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->commit();
    }

    public function rollback()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'rollback', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getClassMetadata', array('className' => $className), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'createQuery', array('dql' => $dql), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'createNamedQuery', array('name' => $name), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'createQueryBuilder', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'flush', array('entity' => $entity), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'clear', array('entityName' => $entityName), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->clear($entityName);
    }

    public function close()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'close', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->close();
    }

    public function persist($entity)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'persist', array('entity' => $entity), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'remove', array('entity' => $entity), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'refresh', array('entity' => $entity), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'detach', array('entity' => $entity), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'merge', array('entity' => $entity), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getRepository', array('entityName' => $entityName), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'contains', array('entity' => $entity), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getEventManager', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getConfiguration', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'isOpen', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getUnitOfWork', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getProxyFactory', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'initializeObject', array('obj' => $obj), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'getFilters', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'isFiltersStateClean', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'hasFilters', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return $this->valueHolderfce3e->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializere62fc = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolderfce3e) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderfce3e = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolderfce3e->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, '__get', ['name' => $name], $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        if (isset(self::$publicProperties20d82[$name])) {
            return $this->valueHolderfce3e->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderfce3e;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderfce3e;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, '__set', array('name' => $name, 'value' => $value), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderfce3e;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderfce3e;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, '__isset', array('name' => $name), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderfce3e;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolderfce3e;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, '__unset', array('name' => $name), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderfce3e;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolderfce3e;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, '__clone', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        $this->valueHolderfce3e = clone $this->valueHolderfce3e;
    }

    public function __sleep()
    {
        $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, '__sleep', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;

        return array('valueHolderfce3e');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializere62fc = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializere62fc;
    }

    public function initializeProxy() : bool
    {
        return $this->initializere62fc && ($this->initializere62fc->__invoke($valueHolderfce3e, $this, 'initializeProxy', array(), $this->initializere62fc) || 1) && $this->valueHolderfce3e = $valueHolderfce3e;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderfce3e;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderfce3e;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
