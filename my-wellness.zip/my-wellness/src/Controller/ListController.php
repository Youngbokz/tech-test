<?php

namespace App\Controller;

use App\Entity\Tasks;
use App\Form\TasksType;
use App\Repository\TasksRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ListController extends AbstractController
{
    /**
     * @Route("/list", name="list")
     */
    public function index(TasksRepository $tasksRepo): Response
    {
        return $this->render('list/index.html.twig', [
            'tasks' => $tasksRepo->findAll()
        ]);
    }

    /**
     * @Route("/list/tasks/add", name="user_task_add")
     */
    public function addTask(Request $request): Response
    {
        $task = new Tasks;

        $form = $this->createForm(TasksType::class, $task);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $task->setUsers($this->getUser());

            $em = $this->getDoctrine()->getManager();
            $em->persist($task);
            $em->flush();

            return $this->redirectToRoute('list');
        }

        return $this->render('list/tasks/add.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/list/tasks/update/{id}", name="user_task_update")
     */
    public function updateTask(Tasks $task, Request $request): Response
    {

        $form = $this->createForm(TasksType::class, $task);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $task->setUsers($this->getUser());

            $em = $this->getDoctrine()->getManager();
            $em->persist($task);
            $em->flush();

            return $this->redirectToRoute('list');
        }

        return $this->render('list/tasks/update.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/list/tasks/delete/{id}", name="user_task_delete")
     */
    public function deleteTask(Tasks $task, Request $request): Response
    {

        $em = $this->getDoctrine()->getManager();
        $em->remove($task);
        $em->flush();

        $this->addFlash('message', 'deleted with success !');
        return $this->redirectToRoute('list');
    }
}
